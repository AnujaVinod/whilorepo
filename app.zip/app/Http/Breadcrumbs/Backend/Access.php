<?php

require __DIR__ . '/Access/User.php';
require __DIR__ . '/Access/Role.php';
require __DIR__ . '/Access/Permission.php';
require __DIR__ . '/Access/PermissionGroup.php';