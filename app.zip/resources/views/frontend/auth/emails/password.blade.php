{{ trans('strings.emails.reset_password') }}: {{ url('password/reset/'.$token) }}
