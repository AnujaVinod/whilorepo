@extends('frontend.layouts.master')

@section('content')
<div class="pg-opt">
        <div class="container">
            <div class="row">
                <div class="col-xs-6">
                    <h2> @foreach ($data['myjobs']['profile'] as $details) {{ $details }} @endforeach</h2>
                </div>
                <div class="col-xs-6">
                    <ol class="breadcrumb">
                        <li><a href="#">Home</a></li>
                        <li class="active">Myaccount</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

 <section class="slice bg-white">
        <div class="wp-section user-account">
            <div class="container">
                <div class="row">
                    <div class="col-md-2">
                      
                       <div class="user-profile-img">
                       @foreach ($data['myjobs']['logo'] as $list)
                           <img src="<?php echo $list->logoCategory == "" ? "" : "companylogo.get/" ?>{{ $list->logoCategory }}/{{ $list->dirYear }}/{{ $list->dirMonth }}/{{ $list->logoName }}/{{ $list->crTime }}/s.{{ $list->logExt }}" class="img-responsive" style="width:100%">
						  @endforeach
                        </div>
                       
                        <ul class="categories">
                            <li><a href="#myjobs" data-toggle="tab" aria-expanded="true">Jobs Posted</a></li>
                            <li><a href="#shortlist" data-toggle="tab" aria-expanded="true">Shortlist</a></li>
                            <li><a href="#favorite" data-toggle="tab" aria-expanded="true">Favorite list</a></li>
                            
                        </ul>
                    </div>
                    <div class="col-md-10">                     
                        <div class="tabs-framed">
                            <div class="tab-content">
                               <div class="tab-pane fade active in" id="myjobs">
                                    <div class="tab-body">
                                        <div class="panel-heading">
                                        <h4 class="panel-title">
                                            
                                           My jobs
                                           
                                        </h4>
                                    </div>
                                        <div class="row" style="margin-bottom: -7px;">                                        
                                 <table class="table table-orders table-bordered table-striped table-responsive no-margin" name="myjobs">
                                        <thead>
                                         <th width="5%">Sl-No</th>
                                        <th width="30%">Job Title</th>
                                      
                                        <th>Total Applied</th>
                                        <th>Expiry date</th>
                                        <th>Created Date</th>
                                        <th>Status</th>
                                        <th>Controls</th>
                                             
                                        </thead>
                                        <tbody>
                                         <?php $i = 0 ?>
                                         @foreach ($data['myjobs']['jobs'] as $jobs) <?php $i = $i + 1 ?>
                                           <tr id="{{ $jobs->jobId }}" style="animation: color 1s ease-in-out 0 1 normal both;">
                                           		<td><?php echo $i; ?></td>
                                                <td><a href="#">{{ $jobs->jobTitle }}</a></td>
                                               
                                                <td>@if($jobs->totalcount != null) <a target="_blank" href="appliedlist/{{ $jobs->jobId }}/{{ $jobs->totalcount}}">{{ $jobs->totalcount}} (<span style="color:#060">{{ $jobs->totalunseen }} New</span>)</a> @else 0 @endif</td>
                                                <td><span style="color: <?php if(strtotime(date("d-m-Y")) <  strtotime($jobs->lastdate)) echo "green"; else echo "red"; ?>"> {{ $jobs->lastdate }}</span></td>
                                                <td><?php echo date("d-m-Y", strtotime($jobs->createdDate)); ?></td>
                                                <td class="{{ ($jobs->status == 1) ? "active" : "inactive" }}"><span class="label label-{{ ($jobs->status == 1) ? "success" : "default" }}">{{ ($jobs->status == 1) ? "Active" : "Inactive" }}</span></td>
                                                <td><div class="dropdown">
    <a data-target="#" href="page.html" data-toggle="dropdown" class="dropdown-toggle">Options <b class="caret"></b></a>
    <ul class="dropdown-menu">
                <li><a class="view" href="javascript:void(0)">View</a></li>
                <li><a class="edit" href="javascript:void(0)">Edit</a></li>
              {!! ($jobs->status == 1) ? "<li><a class='hidetemp' href='javascript:void(0)'>Hide</a></li>" : "<li><a class='activetemp' href='javascript:void(0)'>Active</a></li>" !!}
                <li class="divider"></li>
                <li><a class="delete" href="javascript:void(0)">Trash</a></li>
            </ul>  
</div></td>
                                            </tr>
                                             @endforeach
                                           
										</tbody>
                                       
                                    </table>
                                   <ul name="myjobstotalpage" class="pagination-sm pagination"><li class="disabled"><a>Page {{ $data['myjobs']['count'] }} / <b>1</b></a></li></ul><ul name="myjobspagination" class="pagination-sm pagination">
                                  
                                   </ul>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="tab-pane fade in" id="shortlist">
                                    <div class="tab-body">
                                        <h3 class="title title-lg">Short list</h3>
                                        <div class="row">                                        
                                            <table class="table table-orders table-bordered table-striped table-responsive no-margin">
                                      		  <tbody>
                                            <tr>
                                                <th>SLNO</th>
                                                <th>Full Name</th>
                                                <th>Mobile</th>
                                                <th>Email Address</th>
                                                <th>Created Date</th>
                                                <th>Action</th>
                                            </tr>
                                        
                                            <tr>
                                                <td><a href="#">Ramachandra</a></td>
                                                <td>MCA</td>
                                                <td>2 Years</td>
                                                <td>26</td>
                                                <td><a class="status">View Profile  </a>                                   </td>
                                            </tr>
										</tbody>
                                        </table>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="tab-pane fade in" id="favorite">
                                    <div class="tab-body">
                                        <h3 class="title title-lg">Favorite</h3>
                                        <div class="row">                                        
                                             <table class="table table-orders table-bordered table-striped table-responsive no-margin">
                                      		  <tbody>
                                            <tr>
                                                <th>SLNO</th>
                                                <th>Full Name</th>
                                                <th>Mobile</th>
                                                <th>Email Address</th>
                                                <th>Created Date</th>
                                                <th>Action</th>
                                            </tr>
                                        
                                            <tr>
                                                <td><a href="#">Ramachandra</a></td>
                                                <td>MCA</td>
                                                <td>2 Years</td>
                                                <td>26</td>
                                                <td><a class="status">View Profile  </a>                                   </td>
                                            </tr>
										</tbody>
                                        </table>
                                        </div>
                                    </div>
                                </div>
                                
                                
  
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
     <script>var today = "<?php echo strtotime(date("d-m-Y")) . "000"; ?>";</script>  
@endsection

@section('after-scripts-end')

   <script type="text/javascript" src="/js/jquery.twbsPagination.js"></script>
   <script src="/assets/app/myaccount.company.js"></script>
    @if ($data['myjobs']['count'] > 1)
     <script>
	 $(function(){ 
		
	
	 $('[name=myjobspagination]').twbsPagination({
        totalPages: "{{ $data['count'] }}",
        visiblePages: 7,
        onPageClick: function (event, page) { 
		   $('[name=myjobstotalpage] li a b').html(page); 
            $.companyacount.paginationmyjobs(page);
        }
    });
   })(jQuery); </script>@endif
   
@stop