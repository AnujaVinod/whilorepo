
window.onload = function () {
	
	
		$('body').addClass('loaded');
		
};